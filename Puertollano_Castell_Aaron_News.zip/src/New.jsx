import "./App.css";
import Header from "./Header";
import NewSory from "./NewStory";
import Footer from "./Footer";

function App() {
  return (
    <>
      <Header />

      <NewSory />

      <Footer />
    </>
  );
}

export default App;
